package com.example.callvoice

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.*

data class Rule(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Night delivery",
    val enabled: Boolean = true,
    val start: Int = 23 * 60, val end: Int = 8 * 60,
    val days: Int = 127, val sim: Int = -1,
    val delay: Int = 3, val repeat: Int = 2, val hangup: Int = 4,
    val audioMode: Int = 0, val boost: Int = 6
) {
    fun activeNow(): Boolean {
        if (!enabled) return false
        val c = Calendar.getInstance()
        val m = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        val inTime = if (start <= end) m in start until end else (m >= start || m < end)
        var d = c.get(Calendar.DAY_OF_WEEK) - 1
        if (start > end && m < end) d = (d + 6) % 7
        return inTime && ((days shr d) and 1) == 1
    }
    fun toJson() = JSONObject().put("id", id).put("name", name).put("enabled", enabled).put("start", start)
        .put("end", end).put("days", days).put("sim", sim).put("delay", delay).put("repeat", repeat)
        .put("hangup", hangup).put("audioMode", audioMode).put("boost", boost)
    companion object {
        fun from(o: JSONObject) = Rule(o.getString("id"), o.getString("name"), o.getBoolean("enabled"), o.getInt("start"),
            o.getInt("end"), o.getInt("days"), o.getInt("sim"), o.getInt("delay"), o.getInt("repeat"), o.getInt("hangup"),
            o.optInt("audioMode", 0), o.optInt("boost", 6))
    }
}

data class LogE(val t: Long, val msg: String)

object Store {
    private fun p(c: Context) = c.getSharedPreferences("cvr", Context.MODE_PRIVATE)
    fun master(c: Context) = p(c).getBoolean("master", false)
    fun setMaster(c: Context, v: Boolean) = p(c).edit().putBoolean("master", v).apply()
    fun rules(c: Context): List<Rule> {
        val a = JSONArray(p(c).getString("rules", "[]"))
        return (0 until a.length()).map { Rule.from(a.getJSONObject(it)) }
    }
    fun save(c: Context, l: List<Rule>) {
        val a = JSONArray(); l.forEach { a.put(it.toJson()) }
        p(c).edit().putString("rules", a.toString()).apply()
    }
    fun voice(c: Context, id: String) = File(c.filesDir, "voice_$id.m4a")
}

object Logs {
    private fun p(c: Context) = c.getSharedPreferences("cvr", Context.MODE_PRIVATE)
    @Synchronized fun add(c: Context, m: String) {
        val old = JSONArray(p(c).getString("logs", "[]"))
        val n = JSONArray().put(JSONObject().put("t", System.currentTimeMillis()).put("m", m))
        for (i in 0 until minOf(old.length(), 79)) n.put(old.get(i))
        p(c).edit().putString("logs", n.toString()).apply()
    }
    fun all(c: Context): List<LogE> {
        val a = JSONArray(p(c).getString("logs", "[]"))
        return (0 until a.length()).map { LogE(a.getJSONObject(it).getLong("t"), a.getJSONObject(it).getString("m")) }
    }
    fun clear(c: Context) = p(c).edit().putString("logs", "[]").apply()
}
