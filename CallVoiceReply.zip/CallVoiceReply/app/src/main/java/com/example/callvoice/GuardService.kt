package com.example.callvoice

import android.annotation.SuppressLint
import android.app.*
import android.content.*
import android.media.*
import android.media.audiofx.LoudnessEnhancer
import android.os.*
import android.telecom.TelecomManager
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/** Always-on foreground service: watches for incoming calls even when the app UI is closed. */
@SuppressLint("MissingPermission")
class GuardService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var mp: MediaPlayer? = null
    private var enhancer: LoudnessEnhancer? = null
    private var handling = false
    private var lastRing = 0L
    private lateinit var am: AudioManager

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.getStringExtra(TelephonyManager.EXTRA_STATE)) {
                TelephonyManager.EXTRA_STATE_RINGING -> onRing(slotOf(i))
                TelephonyManager.EXTRA_STATE_IDLE -> onIdle()
            }
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        am = getSystemService(AudioManager::class.java)
        ContextCompat.registerReceiver(this, rx, IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED), ContextCompat.RECEIVER_EXPORTED)
    }

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("guard", "Auto-reply status", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, "guard").setSmallIcon(android.R.drawable.sym_call_incoming)
            .setContentTitle("Call Voice Reply is active").setContentText("Waiting for incoming calls")
            .setContentIntent(open).setOngoing(true).build()
        startForeground(1, n)
        return START_STICKY
    }

    private fun slotOf(i: Intent): Int = try {
        val sub = i.getIntExtra("subscription", -1)
        getSystemService(SubscriptionManager::class.java).activeSubscriptionInfoList
            ?.firstOrNull { it.subscriptionId == sub }?.simSlotIndex ?: -1
    } catch (e: Exception) { -1 }

    private fun onRing(slot: Int) {
        val now = System.currentTimeMillis()
        if (now - lastRing < 3000 || handling) return
        lastRing = now
        if (!Store.master(this)) return
        val rule = Store.rules(this).firstOrNull { it.activeNow() && (it.sim == -1 || slot == -1 || it.sim == slot) }
        if (rule == null) { Logs.add(this, "Call came — no active rule right now, ignored"); return }
        if (!Store.voice(this, rule.id).exists()) { Logs.add(this, "Rule '${rule.name}' matched but NO voice recorded"); return }
        handling = true
        Logs.add(this, "Ringing — rule '${rule.name}', answering in ${rule.delay}s")
        h.postDelayed({ answer(rule) }, rule.delay * 1000L)
    }

    private fun answer(r: Rule) {
        val ts = getSystemService(TelephonyManager::class.java)
        if (ts.callState != TelephonyManager.CALL_STATE_RINGING) { Logs.add(this, "Caller hung up before answer"); handling = false; return }
        val ok = runCatching { getSystemService(TelecomManager::class.java).acceptRingingCall() }.isSuccess
        Logs.add(this, if (ok) "Call answered" else "Answer FAILED (permission?)")
        if (!ok) { handling = false; return }
        h.postDelayed({ play(r, 1) }, 1500)
    }

    private fun play(r: Rule, n: Int) {
        runCatching {
            val voiceMode = r.audioMode == 1
            am.mode = AudioManager.MODE_IN_CALL
            am.isSpeakerphoneOn = true
            am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, am.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL), 0)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0)
            releasePlayer()
            mp = MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(if (voiceMode) AudioAttributes.USAGE_VOICE_COMMUNICATION else AudioAttributes.USAGE_MEDIA)
                    .setContentType(if (voiceMode) AudioAttributes.CONTENT_TYPE_SPEECH else AudioAttributes.CONTENT_TYPE_MUSIC).build())
                setDataSource(Store.voice(this@GuardService, r.id).path)
                prepare()
                if (r.boost > 0) runCatching {
                    enhancer = LoudnessEnhancer(audioSessionId).apply { setTargetGain(r.boost * 100); enabled = true }
                }
                setOnCompletionListener {
                    if (n < r.repeat) h.postDelayed({ play(r, n + 1) }, 1000)
                    else h.postDelayed({
                        runCatching { getSystemService(TelecomManager::class.java).endCall() }
                        Logs.add(this@GuardService, "Message played ${r.repeat}×, call ended")
                        cleanup()
                    }, r.hangup * 1000L)
                }
                start()
            }
            if (n == 1) Logs.add(this, "Playing voice (${if (voiceMode) "call" else "media"} mode, +${r.boost}dB)")
        }.onFailure { Logs.add(this, "Playback error: ${it.message}"); cleanup() }
    }

    private fun releasePlayer() {
        runCatching { enhancer?.release() }; enhancer = null
        runCatching { mp?.release() }; mp = null
    }

    private fun cleanup() {
        h.removeCallbacksAndMessages(null)
        releasePlayer()
        runCatching { am.isSpeakerphoneOn = false; am.mode = AudioManager.MODE_NORMAL }
        handling = false
    }

    private fun onIdle() { if (handling) Logs.add(this, "Call finished"); cleanup() }

    override fun onDestroy() {
        runCatching { unregisterReceiver(rx) }
        cleanup()
        super.onDestroy()
    }
}
