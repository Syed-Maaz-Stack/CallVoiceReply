package com.example.callvoice

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat

class CallReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        when (i.getStringExtra(TelephonyManager.EXTRA_STATE)) {
            TelephonyManager.EXTRA_STATE_IDLE -> c.stopService(Intent(c, CallService::class.java))
            TelephonyManager.EXTRA_STATE_RINGING -> {
                if (!Store.master(c)) return
                val slot = slotOf(c, i)
                val rule = Store.rules(c).firstOrNull {
                    it.activeNow() && (it.sim == -1 || slot == -1 || it.sim == slot) && Store.voice(c, it.id).exists()
                } ?: return
                ContextCompat.startForegroundService(c, Intent(c, CallService::class.java).putExtra("rule", rule.id))
            }
        }
    }

    @Suppress("MissingPermission")
    private fun slotOf(c: Context, i: Intent): Int = try {
        val sub = i.getIntExtra("subscription", -1)
        c.getSystemService(SubscriptionManager::class.java).activeSubscriptionInfoList
            ?.firstOrNull { it.subscriptionId == sub }?.simSlotIndex ?: -1
    } catch (e: Exception) { -1 }
}
