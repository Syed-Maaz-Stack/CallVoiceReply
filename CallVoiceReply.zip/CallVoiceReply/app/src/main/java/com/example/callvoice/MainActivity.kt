package com.example.callvoice

import android.Manifest
import android.app.TimePickerDialog
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

// Claude-style palette
private val Clay = Color(0xFFD97757)
private val LightScheme = lightColorScheme(primary = Clay, onPrimary = Color.White, background = Color(0xFFFAF9F5),
    surface = Color(0xFFFFFFFF), onSurface = Color(0xFF141413), onBackground = Color(0xFF141413),
    surfaceVariant = Color(0xFFF0EEE6), onSurfaceVariant = Color(0xFF6B6A63), outline = Color(0xFFE3DFD2),
    secondaryContainer = Color(0xFFF3DDD3), onSecondaryContainer = Color(0xFF8A3F22))
private val DarkScheme = darkColorScheme(primary = Clay, onPrimary = Color.White, background = Color(0xFF262624),
    surface = Color(0xFF30302E), onSurface = Color(0xFFFAF9F5), onBackground = Color(0xFFFAF9F5),
    surfaceVariant = Color(0xFF3A3A37), onSurfaceVariant = Color(0xFFB5B3A8), outline = Color(0xFF4A4945),
    secondaryContainer = Color(0xFF5A3426), onSecondaryContainer = Color(0xFFF3DDD3))
private val Serif = FontFamily.Serif

fun fmt(m: Int): String { val h = m / 60; val ap = if (h < 12) "AM" else "PM"; return "%d:%02d %s".format(if (h % 12 == 0) 12 else h % 12, m % 60, ap) }
private val DAYS = listOf("S", "M", "T", "W", "T", "F", "S")
private val PERMS = buildList {
    add(Manifest.permission.READ_PHONE_STATE); add(Manifest.permission.ANSWER_PHONE_CALLS); add(Manifest.permission.RECORD_AUDIO)
    if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
}.toTypedArray()
private fun granted(c: Context) = PERMS.all { ContextCompat.checkSelfPermission(c, it) == PackageManager.PERMISSION_GRANTED }

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContent { MaterialTheme(colorScheme = if (androidx.compose.foundation.isSystemInDarkTheme()) DarkScheme else LightScheme) { Root() } }
    }
}

@Composable
fun Root() {
    val c = LocalContext.current
    val rules = remember { mutableStateListOf<Rule>().apply { addAll(Store.rules(c)) } }
    var master by remember { mutableStateOf(Store.master(c)) }
    var ok by remember { mutableStateOf(granted(c)) }
    var editing by remember { mutableStateOf<Rule?>(null) }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { ok = granted(c) }
    fun persist() = Store.save(c, rules.toList())
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        val e = editing
        if (e != null) {
            BackHandler { editing = null }
            Editor(e, onSave = { r -> val i = rules.indexOfFirst { it.id == r.id }; if (i >= 0) rules[i] = r else rules.add(r); persist(); editing = null },
                onDelete = { rules.removeAll { it.id == e.id }; Store.voice(c, e.id).delete(); persist(); editing = null },
                onBack = { editing = null })
        } else Home(rules, master, ok, { master = it; Store.setMaster(c, it) }, { ask.launch(PERMS) },
            { editing = Rule() }, { editing = it }, { r, on -> rules[rules.indexOf(r)] = r.copy(enabled = on); persist() })
    }
}

@Composable
fun Home(rules: List<Rule>, master: Boolean, ok: Boolean, onMaster: (Boolean) -> Unit, onGrant: () -> Unit,
         onAdd: () -> Unit, onEdit: (Rule) -> Unit, onToggle: (Rule, Boolean) -> Unit) {
    val active = rules.count { it.enabled }
    Scaffold(containerColor = MaterialTheme.colorScheme.background, floatingActionButton = {
        FloatingActionButton(onClick = onAdd, containerColor = Clay, contentColor = Color.White, shape = RoundedCornerShape(18.dp)) { Icon(Icons.Default.Add, "Add") }
    }) { pad ->
        LazyColumn(Modifier.padding(pad).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Spacer(Modifier.height(24.dp))
                Text("Call Voice Reply", fontFamily = Serif, fontSize = 32.sp, fontWeight = FontWeight.Medium)
                Text("Auto-answer calls & play your voice while you sleep", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
            }
            item {
                Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = if (master) Clay else MaterialTheme.colorScheme.surfaceVariant)) {
                    Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            val fg = if (master) Color.White else MaterialTheme.colorScheme.onSurface
                            Text(if (master) "Auto-reply is ON" else "Auto-reply is OFF", fontFamily = Serif, fontSize = 22.sp, color = fg)
                            Text("$active rule(s) enabled", color = fg.copy(alpha = .8f))
                        }
                        Switch(master, onMaster, colors = SwitchDefaults.colors(checkedTrackColor = Color(0xFF8A3F22), checkedThumbColor = Color.White))
                    }
                }
            }
            if (!ok) item {
                Card(shape = RoundedCornerShape(20.dp), border = BorderStroke(1.dp, Clay), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(20.dp)) {
                        Text("Permissions needed", fontFamily = Serif, fontSize = 18.sp)
                        Text("Phone state, answer calls, microphone and notifications.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(10.dp))
                        Button(onGrant, colors = ButtonDefaults.buttonColors(containerColor = Clay)) { Text("Grant permissions") }
                    }
                }
            }
            item { Text("Rules", fontFamily = Serif, fontSize = 20.sp, modifier = Modifier.padding(top = 8.dp)) }
            if (rules.isEmpty()) item { Text("No rules yet. Tap + to add one, set the time, SIM and record your voice.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(rules, key = { it.id }) { r ->
                val has = Store.voice(LocalContext.current, r.id).exists()
                Card(Modifier.clickable { onEdit(r) }, shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(r.name, fontFamily = Serif, fontSize = 18.sp)
                            Text("${fmt(r.start)} → ${fmt(r.end)}  ·  " + (if (r.sim == -1) "Any SIM" else "SIM ${r.sim + 1}"), color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(if (has) "Voice recorded ✓" else "No voice yet", color = if (has) Clay else MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        }
                        Switch(r.enabled, { onToggle(r, it) }, colors = SwitchDefaults.colors(checkedTrackColor = Clay, checkedThumbColor = Color.White))
                    }
                }
            }
            item { Spacer(Modifier.height(90.dp)) }
        }
    }
}

@Composable
fun Editor(initial: Rule, onSave: (Rule) -> Unit, onDelete: () -> Unit, onBack: () -> Unit) {
    val c = LocalContext.current
    var r by remember { mutableStateOf(initial) }
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var hasVoice by remember { mutableStateOf(Store.voice(c, r.id).exists()) }
    DisposableEffect(Unit) { onDispose { runCatching { recorder?.release() }; player?.release() } }
    fun pickTime(cur: Int, set: (Int) -> Unit) = TimePickerDialog(c, { _, h, m -> set(h * 60 + m) }, cur / 60, cur % 60, false).show()
    fun toggleRec() {
        if (recorder == null) {
            if (ContextCompat.checkSelfPermission(c, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
            recorder = (if (Build.VERSION.SDK_INT >= 31) MediaRecorder(c) else MediaRecorder()).apply {
                setAudioSource(MediaRecorder.AudioSource.MIC); setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC); setAudioEncodingBitRate(96000); setAudioSamplingRate(44100)
                setOutputFile(Store.voice(c, r.id).path); prepare(); start()
            }
        } else { runCatching { recorder?.stop() }; recorder?.release(); recorder = null; hasVoice = Store.voice(c, r.id).exists() }
    }
    fun play() { player?.release(); player = MediaPlayer().apply { setDataSource(Store.voice(c, r.id).path); prepare(); start() } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Spacer(Modifier.height(12.dp))
        TextButton(onBack) { Text("← Back", color = Clay) }
        Text("Edit rule", fontFamily = Serif, fontSize = 30.sp)
        OutlinedTextField(r.name, { r = r.copy(name = it) }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)

        Section("Time window") {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton({ pickTime(r.start) { r = r.copy(start = it) } }, Modifier.weight(1f)) { Text("From  ${fmt(r.start)}", color = MaterialTheme.colorScheme.onSurface) }
                OutlinedButton({ pickTime(r.end) { r = r.copy(end = it) } }, Modifier.weight(1f)) { Text("To  ${fmt(r.end)}", color = MaterialTheme.colorScheme.onSurface) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                DAYS.forEachIndexed { i, d ->
                    FilterChip(((r.days shr i) and 1) == 1, { r = r.copy(days = r.days xor (1 shl i)) }, { Text(d) }, colors = chipColors())
                }
            }
        }
        Section("SIM") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(-1 to "Any", 0 to "SIM 1", 1 to "SIM 2").forEach { (v, l) ->
                    FilterChip(r.sim == v, { r = r.copy(sim = v) }, { Text(l) }, colors = chipColors())
                }
            }
        }
        Section("Your voice message") {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(::toggleRec, colors = ButtonDefaults.buttonColors(containerColor = if (recorder != null) Color(0xFF8A3F22) else Clay)) { Text(if (recorder != null) "■ Stop" else if (hasVoice) "● Re-record" else "● Record") }
                OutlinedButton(::play, enabled = hasVoice && recorder == null) { Text("▶ Play", color = MaterialTheme.colorScheme.onSurface) }
            }
            Text(if (hasVoice) "Voice saved ✓" else "Say your address clearly, 10–15 sec.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        }
        Section("Behaviour") {
            Slid("Answer after", r.delay, 0..15, "s") { r = r.copy(delay = it) }
            Slid("Repeat message", r.repeat, 1..5, "×") { r = r.copy(repeat = it) }
            Slid("Hang up after message", r.hangup, 2..15, "s") { r = r.copy(hangup = it) }
        }
        Button({ onSave(r) }, Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Clay)) { Text("Save rule", fontSize = 16.sp) }
        TextButton(onDelete, Modifier.fillMaxWidth()) { Text("Delete rule", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        Spacer(Modifier.height(30.dp))
    }
}

@Composable private fun chipColors() = FilterChipDefaults.filterChipColors(selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer, selectedLabelColor = MaterialTheme.colorScheme.onSecondaryContainer)

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, fontFamily = Serif, fontSize = 18.sp); content()
        }
    }
}

@Composable
private fun Slid(label: String, v: Int, range: IntRange, unit: String, on: (Int) -> Unit) {
    Column {
        Text("$label: $v$unit", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Slider(v.toFloat(), { on(it.toInt()) }, valueRange = range.first.toFloat()..range.last.toFloat(), steps = range.last - range.first - 1,
            colors = SliderDefaults.colors(thumbColor = Clay, activeTrackColor = Clay))
    }
}
