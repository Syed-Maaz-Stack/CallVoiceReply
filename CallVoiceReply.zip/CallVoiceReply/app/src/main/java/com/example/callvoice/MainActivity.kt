package com.example.callvoice

import android.Manifest
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val P1 = Color(0xFF8B5CF6); private val P2 = Color(0xFFC084FC); private val P3 = Color(0xFF6D28D9)
private val Ink = Color(0xFF0B0816); private val Surf = Color(0xFF1A1336); private val Edge = Color(0xFF2C2354)
private val Muted = Color(0xFFA79FC4)
private val Grad = Brush.linearGradient(listOf(P3, P1, P2))
private val BgGrad = Brush.verticalGradient(listOf(Color(0xFF1E1147), Ink))
private val Scheme = darkColorScheme(primary = P1, onPrimary = Color.White, background = Ink, surface = Surf,
    onSurface = Color.White, onBackground = Color.White, surfaceVariant = Surf, onSurfaceVariant = Muted, outline = Edge,
    secondaryContainer = Color(0xFF3B2A78), onSecondaryContainer = Color.White)

fun fmt(m: Int): String { val h = m / 60; val ap = if (h < 12) "AM" else "PM"; return "%d:%02d %s".format(if (h % 12 == 0) 12 else h % 12, m % 60, ap) }
private val DAYS = listOf("S", "M", "T", "W", "T", "F", "S")
private val PERMS = buildList {
    add(Manifest.permission.READ_PHONE_STATE); add(Manifest.permission.ANSWER_PHONE_CALLS); add(Manifest.permission.RECORD_AUDIO)
    if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
}.toTypedArray()
private fun granted(c: Context) = PERMS.all { ContextCompat.checkSelfPermission(c, it) == PackageManager.PERMISSION_GRANTED }

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContent { MaterialTheme(colorScheme = Scheme) { Root(tick) } }
    }
    override fun onResume() { super.onResume(); tick++ }
}

@Composable
fun Root(tick: Int) {
    val c = LocalContext.current
    val rules = remember { mutableStateListOf<Rule>().apply { addAll(Store.rules(c)) } }
    var master by remember { mutableStateOf(Store.master(c)) }
    var ok by remember(tick) { mutableStateOf(granted(c)) }
    val battOk = remember(tick) { c.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(c.packageName) }
    var editing by remember { mutableStateOf<Rule?>(null) }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { ok = granted(c) }
    LaunchedEffect(master) {
        val i = Intent(c, GuardService::class.java)
        if (master) runCatching { ContextCompat.startForegroundService(c, i) } else c.stopService(i)
    }
    fun persist() = Store.save(c, rules.toList())
    Box(Modifier.fillMaxSize().background(BgGrad)) {
        val e = editing
        if (e != null) {
            BackHandler { editing = null }
            Editor(e, onSave = { r -> val i = rules.indexOfFirst { it.id == r.id }; if (i >= 0) rules[i] = r else rules.add(r); persist(); editing = null },
                onDelete = { rules.removeAll { it.id == e.id }; Store.voice(c, e.id).delete(); persist(); editing = null },
                onBack = { editing = null })
        } else Home(rules, master, ok, battOk, { master = it; Store.setMaster(c, it) }, { ask.launch(PERMS) },
            { runCatching { c.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${c.packageName}"))) } },
            { editing = Rule() }, { editing = it }, { r, on -> rules[rules.indexOf(r)] = r.copy(enabled = on); persist() })
    }
}

@Composable
fun Home(rules: List<Rule>, master: Boolean, ok: Boolean, battOk: Boolean, onMaster: (Boolean) -> Unit, onGrant: () -> Unit,
         onBatt: () -> Unit, onAdd: () -> Unit, onEdit: (Rule) -> Unit, onToggle: (Rule, Boolean) -> Unit) {
    val c = LocalContext.current
    var tab by remember { mutableStateOf(0) }
    var logTick by remember { mutableStateOf(0) }
    val logs = remember(logTick, tab) { Logs.all(c) }
    val df = remember { SimpleDateFormat("dd MMM, hh:mm:ss a", Locale.getDefault()) }
    Box(Modifier.fillMaxSize()) {
        LazyColumn(contentPadding = PaddingValues(20.dp, 24.dp, 20.dp, 110.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Text("Call Voice Reply", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text("Auto-answer calls & play your voice while you sleep", color = Muted)
            }
            item {
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(if (master) Grad else Brush.linearGradient(listOf(Surf, Surf)))
                    .border(1.dp, Edge, RoundedCornerShape(24.dp)).padding(22.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(if (master) "Auto-reply is ON" else "Auto-reply is OFF", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text(if (master) "Listening in background · ${rules.count { it.enabled }} rule(s)" else "Turn on to start listening",
                            color = if (master) Color.White.copy(.85f) else Muted)
                    }
                    Switch(master, onMaster, colors = SwitchDefaults.colors(checkedTrackColor = Color.White.copy(.35f), checkedThumbColor = Color.White,
                        checkedBorderColor = Color.Transparent))
                }
            }
            if (!ok) item {
                Panel { Text("Permissions needed", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    Text("Phone, answer calls, microphone, notifications.", color = Muted)
                    Spacer(Modifier.height(10.dp)); GButton("Grant permissions", onClick = onGrant) }
            }
            if (!battOk) item {
                Panel { Text("Keep it alive in background", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    Text("Allow 'no battery restriction' so the phone doesn't kill the app while you sleep.", color = Muted)
                    Spacer(Modifier.height(10.dp)); GButton("Allow", onClick = onBatt) }
            }
            item {
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Surf).padding(4.dp)) {
                    listOf("Rules", "Logs").forEachIndexed { i, t ->
                        Box(Modifier.weight(1f).clip(RoundedCornerShape(11.dp)).then(if (tab == i) Modifier.background(Grad) else Modifier)
                            .clickable { tab = i }.padding(10.dp), contentAlignment = Alignment.Center) {
                            Text(t, fontWeight = FontWeight.SemiBold, color = if (tab == i) Color.White else Muted)
                        }
                    }
                }
            }
            if (tab == 0) {
                if (rules.isEmpty()) item { Text("No rules yet. Tap + to add one: set time, SIM and record your voice.", color = Muted) }
                items(rules, key = { it.id }) { r ->
                    val has = Store.voice(c, r.id).exists()
                    Panel(onClick = { onEdit(r) }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(r.name, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                                Text("${fmt(r.start)} → ${fmt(r.end)} · " + (if (r.sim == -1) "Any SIM" else "SIM ${r.sim + 1}"), color = Muted)
                                Text(if (has) "Voice recorded ✓" else "No voice yet", color = if (has) P2 else Muted, fontSize = 13.sp)
                            }
                            Switch(r.enabled, { onToggle(r, it) }, colors = SwitchDefaults.colors(checkedTrackColor = P1, checkedThumbColor = Color.White, checkedBorderColor = Color.Transparent))
                        }
                    }
                }
            } else {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        GhostButton("Refresh") { logTick++ }
                        GhostButton("Clear") { Logs.clear(c); logTick++ }
                    }
                }
                if (logs.isEmpty()) item { Text("No activity yet. When a call comes in, what the app did will appear here.", color = Muted) }
                items(logs) { l ->
                    Panel { Text(df.format(Date(l.t)), color = P2, fontSize = 12.sp); Text(l.msg) }
                }
            }
        }
        if (tab == 0) Box(Modifier.align(Alignment.BottomEnd).padding(24.dp).size(62.dp).clip(CircleShape).background(Grad).clickable(onClick = onAdd),
            Alignment.Center) { Icon(Icons.Default.Add, "Add", tint = Color.White) }
    }
}

@Composable
fun Editor(initial: Rule, onSave: (Rule) -> Unit, onDelete: () -> Unit, onBack: () -> Unit) {
    val c = LocalContext.current
    var r by remember { mutableStateOf(initial) }
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var hasVoice by remember { mutableStateOf(Store.voice(c, r.id).exists()) }
    DisposableEffect(Unit) { onDispose { runCatching { recorder?.release() }; player?.release() } }
    fun pickTime(cur: Int, set: (Int) -> Unit) = TimePickerDialog(c, { _, h, m -> set(h * 60 + m) }, cur / 60, cur % 60, false).show()
    fun toggleRec() {
        if (recorder == null) {
            if (ContextCompat.checkSelfPermission(c, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(c, "Go back and tap 'Grant permissions' first", Toast.LENGTH_LONG).show(); return
            }
            recorder = (if (Build.VERSION.SDK_INT >= 31) MediaRecorder(c) else MediaRecorder()).apply {
                setAudioSource(MediaRecorder.AudioSource.MIC); setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC); setAudioEncodingBitRate(128000); setAudioSamplingRate(44100)
                setOutputFile(Store.voice(c, r.id).path); prepare(); start()
            }
        } else { runCatching { recorder?.stop() }; recorder?.release(); recorder = null; hasVoice = Store.voice(c, r.id).exists() }
    }
    fun play() { player?.release(); player = MediaPlayer().apply { setDataSource(Store.voice(c, r.id).path); prepare(); start() } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("← Back", color = P2, modifier = Modifier.clickable(onClick = onBack).padding(vertical = 8.dp))
        Text("Edit rule", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(r.name, { r = r.copy(name = it) }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth(), singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = P1, unfocusedBorderColor = Edge, focusedLabelColor = P2, cursorColor = P2))
        Section("Time window") {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GhostButton("From  ${fmt(r.start)}", Modifier.weight(1f)) { pickTime(r.start) { r = r.copy(start = it) } }
                GhostButton("To  ${fmt(r.end)}", Modifier.weight(1f)) { pickTime(r.end) { r = r.copy(end = it) } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                DAYS.forEachIndexed { i, d -> FilterChip(((r.days shr i) and 1) == 1, { r = r.copy(days = r.days xor (1 shl i)) }, { Text(d) }, colors = chipColors()) }
            }
        }
        Section("SIM") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(-1 to "Any", 0 to "SIM 1", 1 to "SIM 2").forEach { (v, l) -> FilterChip(r.sim == v, { r = r.copy(sim = v) }, { Text(l) }, colors = chipColors()) }
            }
        }
        Section("Your voice message") {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GButton(if (recorder != null) "■ Stop" else if (hasVoice) "● Re-record" else "● Record", onClick = ::toggleRec)
                GhostButton("▶ Play", enabled = hasVoice && recorder == null) { play() }
            }
            Text(if (recorder != null) "Recording… speak clearly" else if (hasVoice) "Voice saved ✓" else "Quiet room, phone close to mouth, 10–15 sec.", color = Muted, fontSize = 13.sp)
        }
        Section("Sound quality") {
            Text("Playback mode", color = Muted)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(r.audioMode == 0, { r = r.copy(audioMode = 0) }, { Text("Media (try first)") }, colors = chipColors())
                FilterChip(r.audioMode == 1, { r = r.copy(audioMode = 1) }, { Text("Call mode") }, colors = chipColors())
            }
            Slid("Loudness boost", r.boost, 0..12, " dB") { r = r.copy(boost = it) }
        }
        Section("Behaviour") {
            Slid("Answer after", r.delay, 0..15, " s") { r = r.copy(delay = it) }
            Slid("Repeat message", r.repeat, 1..5, "×") { r = r.copy(repeat = it) }
            Slid("Hang up after message", r.hangup, 2..15, " s") { r = r.copy(hangup = it) }
        }
        GButton("Save rule", Modifier.fillMaxWidth()) { onSave(r) }
        Text("Delete rule", color = Muted, modifier = Modifier.fillMaxWidth().clickable(onClick = onDelete).padding(12.dp))
        Spacer(Modifier.height(30.dp))
    }
}

@Composable private fun chipColors() = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFF3B2A78), selectedLabelColor = Color.White, labelColor = Muted)

@Composable
private fun Panel(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val s = RoundedCornerShape(20.dp)
    Column(modifier.fillMaxWidth().clip(s).background(Surf).border(1.dp, Edge, s)
        .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(16.dp), content = content)
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) = Panel {
    Text(title, fontSize = 17.sp, fontWeight = FontWeight.SemiBold); Spacer(Modifier.height(10.dp))
    Column(verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
}

@Composable
private fun GButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Box(modifier.clip(RoundedCornerShape(14.dp)).background(if (enabled) Grad else Brush.linearGradient(listOf(Edge, Edge)))
        .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 20.dp, vertical = 14.dp), Alignment.Center) {
        Text(text, color = Color.White, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun GhostButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    val s = RoundedCornerShape(14.dp)
    Box(modifier.clip(s).border(1.dp, Edge, s).clickable(enabled = enabled, onClick = onClick).padding(horizontal = 18.dp, vertical = 13.dp), Alignment.Center) {
        Text(text, color = if (enabled) Color.White else Muted)
    }
}

@Composable
private fun Slid(label: String, v: Int, range: IntRange, unit: String, on: (Int) -> Unit) {
    Column {
        Text("$label: $v$unit", color = Muted)
        Slider(v.toFloat(), { on(it.toInt()) }, valueRange = range.first.toFloat()..range.last.toFloat(), steps = range.last - range.first - 1,
            colors = SliderDefaults.colors(thumbColor = P2, activeTrackColor = P1, inactiveTrackColor = Edge))
    }
}
