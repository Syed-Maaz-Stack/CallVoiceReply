package com.example.callvoice

import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.*
import android.os.*
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import androidx.core.app.NotificationCompat

@SuppressLint("MissingPermission")
class CallService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var mp: MediaPlayer? = null
    private var busy = false
    private lateinit var am: AudioManager

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("cvr", "Auto reply", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(this, "cvr").setSmallIcon(android.R.drawable.sym_call_incoming)
            .setContentTitle("Call Voice Reply").setContentText("Replying to incoming call…").build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK) else startForeground(1, n)
        if (busy) return START_NOT_STICKY
        busy = true
        val rule = Store.rules(this).firstOrNull { it.id == i?.getStringExtra("rule") } ?: run { stopSelf(); return START_NOT_STICKY }
        am = getSystemService(AudioManager::class.java)
        h.postDelayed({ answer(rule) }, rule.delay * 1000L)
        return START_NOT_STICKY
    }

    private fun answer(r: Rule) {
        val tm = getSystemService(TelecomManager::class.java)
        val ts = getSystemService(TelephonyManager::class.java)
        if (ts.callState != TelephonyManager.CALL_STATE_RINGING) { stopSelf(); return }
        tm.acceptRingingCall()
        h.postDelayed({ play(r, 1, tm) }, 1500)
    }

    private fun play(r: Rule, n: Int, tm: TelecomManager) {
        am.mode = AudioManager.MODE_IN_CALL
        am.isSpeakerphoneOn = true
        am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, am.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL), 0)
        mp?.release()
        mp = MediaPlayer().apply {
            setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            setDataSource(Store.voice(this@CallService, r.id).path)
            prepare()
            setOnCompletionListener {
                if (n < r.repeat) h.postDelayed({ play(r, n + 1, tm) }, 1000)
                else h.postDelayed({ tm.endCall(); stopSelf() }, r.hangup * 1000L)
            }
            start()
        }
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        mp?.release(); mp = null
        if (::am.isInitialized) { am.isSpeakerphoneOn = false; am.mode = AudioManager.MODE_NORMAL }
        busy = false
        super.onDestroy()
    }
}
